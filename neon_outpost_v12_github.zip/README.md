# NEON OUTPOST — V12 (coop PeerJS)

## Mettre en ligne avec GitHub Pages
1. Sur GitHub, crée un dépôt (ou vide l'ancien).
2. Envoie CES 5 fichiers à la racine : `index.html`, `neon-outpost-v12.js`, `style.css`, `.nojekyll`, `README.md`.
3. Settings → Pages → Source : "Deploy from a branch" → branche `main`, dossier `/ (root)` → Save.
4. Attends 1-2 minutes, puis ouvre `https://TON-NOM.github.io/NOM-DU-DEPOT/` sur les deux appareils.

## Vérifier que c'est la bonne version
Menu → COOP EN LIGNE : tu dois lire **VERSION RÉSEAU : V12-FRESH-1**.
Si tu lis "ANCIEN SCRIPT", le fichier .js n'est pas à jour sur le site.

## Jouer
Hôte : CRÉER UN SALON → partage le code. Invité : saisit le code → REJOINDRE. L'hôte lance la partie.
Un petit journal réseau s'affiche sous le statut : en cas de souci, envoie-le tel quel.

Réseau : PeerJS (serveur de salons gratuit) + WebRTC (STUN Google/Cloudflare + TURN peerjs.com).
Progression (gemmes, skins, upgrades) sauvegardée localement sur chaque appareil.
